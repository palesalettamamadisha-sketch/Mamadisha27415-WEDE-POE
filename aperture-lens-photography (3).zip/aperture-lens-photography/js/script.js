/* ==========================================================
   APERTURE LENS PHOTOGRAPHY - PART 3 MAIN SCRIPT
   ================================================---------- */

document.addEventListener('DOMContentLoaded', () => {

    /* ------------------------------------------------------
       1. LIGHTBOX MODAL FUNCTIONALITY (For Gallery/Marquee)
       ------------------------------------------------------ */
    const modal = document.getElementById('lightboxModal');
    const modalImg = document.getElementById('lightboxImg');
    const closeBtn = document.getElementById('lightboxClose');

    if (modal && modalImg && closeBtn) {
        document.querySelectorAll('.marquee-item img').forEach(img => {
            img.addEventListener('click', () => {
                modal.classList.add('active');
                modalImg.src = img.src;
            });
        });

        closeBtn.addEventListener('click', () => {
            modal.classList.remove('active');
        });

        modal.addEventListener('click', (e) => {
            if (e.target === modal) {
                modal.classList.remove('active');
            }
        });
    }

    /* ------------------------------------------------------
       2. ENQUIRY FORM VALIDATION & AJAX SIMULATION
       ------------------------------------------------------ */
    const enquiryForm = document.getElementById('enquiryForm');
    if (enquiryForm) {
        enquiryForm.addEventListener('submit', function(e) {
            e.preventDefault();
            let isValid = true;

            const fullname = document.getElementById('fullname');
            const email = document.getElementById('email');
            const phone = document.getElementById('phone');
            const pkg = document.getElementById('package');
            const date = document.getElementById('date');
            const notes = document.getElementById('notes');

            // Reset error states
            document.querySelectorAll('#enquiryForm .error-message').forEach(el => el.classList.remove('visible'));
            document.querySelectorAll('#enquiryForm input, #enquiryForm select, #enquiryForm textarea').forEach(el => el.classList.remove('error'));

            // Validate Full Name
            if (!fullname.value.trim()) {
                fullname.classList.add('error');
                document.getElementById('error-fullname').classList.add('visible');
                isValid = false;
            }

            // Validate Email format
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (!emailRegex.test(email.value.trim())) {
                email.classList.add('error');
                document.getElementById('error-email').classList.add('visible');
                isValid = false;
            }

            // Validate Phone Number format (e.g. 0685169460)
            const phoneRegex = /^0\d{9}$/;
            if (!phoneRegex.test(phone.value.trim().replace(/\s+/g, ''))) {
                phone.classList.add('error');
                document.getElementById('error-phone').classList.add('visible');
                isValid = false;
            }

            // Validate Package selection
            if (!pkg.value) {
                pkg.classList.add('error');
                document.getElementById('error-package').classList.add('visible');
                isValid = false;
            }

            // Validate Date selection
            if (!date.value) {
                date.classList.add('error');
                document.getElementById('error-date').classList.add('visible');
                isValid = false;
            }

            // Validate Project Notes
            if (!notes.value.trim()) {
                notes.classList.add('error');
                document.getElementById('error-notes').classList.add('visible');
                isValid = false;
            }

            // If valid, execute asynchronous AJAX submission response
            if (isValid) {
                const alertBox = document.getElementById('enquirySuccessAlert');
                alertBox.className = 'form-feedback-alert success';
                alertBox.textContent = 'Thank you! Your booking enquiry has been successfully submitted via AJAX. Cost, availability, and scheduling details have been sent to your email.';
                enquiryForm.reset();
                setTimeout(() => { alertBox.style.display = 'none'; }, 6000);
            }
        });
    }

    /* ------------------------------------------------------
       3. CONTACT FORM VALIDATION & AJAX SIMULATION
       ------------------------------------------------------ */
    const contactForm = document.getElementById('contactForm');
    if (contactForm) {
        contactForm.addEventListener('submit', function(e) {
            e.preventDefault();
            let isValid = true;

            const name = document.getElementById('c-name');
            const email = document.getElementById('c-email');
            const msg = document.getElementById('c-msg');

            document.querySelectorAll('#contactForm .error-message').forEach(el => el.classList.remove('visible'));
            document.querySelectorAll('#contactForm input, #contactForm textarea').forEach(el => el.classList.remove('error'));

            if (!name.value.trim()) {
                name.classList.add('error');
                document.getElementById('error-cname').classList.add('visible');
                isValid = false;
            }

            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (!emailRegex.test(email.value.trim())) {
                email.classList.add('error');
                document.getElementById('error-cemail').classList.add('visible');
                isValid = false;
            }

            if (!msg.value.trim()) {
                msg.classList.add('error');
                document.getElementById('error-cmsg').classList.add('visible');
                isValid = false;
            }

            if (isValid) {
                const alertBox = document.getElementById('contactSuccessAlert');
                alertBox.className = 'form-feedback-alert success';
                alertBox.textContent = 'Message sent successfully via AJAX! Your inquiry has been compiled and forwarded to our organization team.';
                contactForm.reset();
                setTimeout(() => { alertBox.style.display = 'none'; }, 6000);
            }
        });
    }

});